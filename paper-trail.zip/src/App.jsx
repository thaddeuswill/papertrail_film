import PaperTrail from "./PaperTrail";
export default function App() { return <PaperTrail />; }
